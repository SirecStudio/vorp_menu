# vorp menu 

RedM menu API

# insatallation

- `ensure vorp_menu` in the top of your resources.cfg 


# features
- supports all resolutions
- menu is responsive width and height 
- descriptions use now wrapping 
- text are centralized
- addNewElements 
- removeElementByindex
- removeElementByvalue
- each elements has a height option 

and many more features

<img width="310" alt="image" src="https://user-images.githubusercontent.com/87246847/177007395-6230bbb6-22cc-459d-8b7b-aa8eced04050.png">




# Credits

* @SLIZZARN
